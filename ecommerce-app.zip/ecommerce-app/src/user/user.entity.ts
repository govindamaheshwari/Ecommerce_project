import { Role } from 'src/role/role.entity';
import { Entity, PrimaryGeneratedColumn, Column, ManyToOne, JoinColumn } from 'typeorm';

@Entity('users')
export class User {
  @PrimaryGeneratedColumn()
  id: number;

  @Column() username: string;
  @Column() email: string;
  @Column() firstName: string;
  @Column() lastName: string;
  @Column() gender: string;
  @Column() phone: string;
  @Column() image: string;
  @Column({ default: false }) is_blocked: boolean;
  @Column({ default: true }) is_active: boolean;

  @ManyToOne(() => Role, (role) => role.users)
  @JoinColumn({ name: 'role_id' })
  role: Role;
}