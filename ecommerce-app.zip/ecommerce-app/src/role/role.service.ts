import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Role } from './role.entity';

@Injectable()
export class RoleService {
  constructor(@InjectRepository(Role) private roleRepo: Repository<Role>) {}

  findAll() {
    return this.roleRepo.find({ relations: ['permissions'] });
  }

  findOne(id: number) {
    return this.roleRepo.findOne({ where: { id }, relations: ['permissions'] });
  }

  create(role: Partial<Role>) {
    return this.roleRepo.save(role);
  }

  update(id: number, role: Partial<Role>) {
    return this.roleRepo.update(id, role);
  }

  delete(id: number) {
    return this.roleRepo.delete(id);
  }
}
