import { Controller, Get, Post, Body, Param, Put, Delete } from '@nestjs/common';
import { PermissionService } from './permission.service';
import { Permission } from './permission.entity';

@Controller('permissions')
export class PermissionController {
  constructor(private readonly permissionService: PermissionService) {}

  @Get()
  findAll() {
    return this.permissionService.findAll();
  }

  @Get(':id')
  findOne(@Param('id') id: number) {
    return this.permissionService.findOne(id);
  }

  @Post()
  create(@Body() permission: Partial<Permission>) {
    return this.permissionService.create(permission);
  }

  @Put(':id')
  update(@Param('id') id: number, @Body() permission: Partial<Permission>) {
    return this.permissionService.update(id, permission);
  }

  @Delete(':id')
  delete(@Param('id') id: number) {
    return this.permissionService.delete(id);
  }
}