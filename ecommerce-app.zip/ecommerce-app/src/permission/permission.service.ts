import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Permission } from './permission.entity';

@Injectable()
export class PermissionService {
  constructor(@InjectRepository(Permission) private permissionRepo: Repository<Permission>) {}

  findAll() {
    return this.permissionRepo.find();
  }

  findOne(id: number) {
    return this.permissionRepo.findOneBy({ id });
  }

  create(permission: Partial<Permission>) {
    return this.permissionRepo.save(permission);
  }

  update(id: number, permission: Partial<Permission>) {
    return this.permissionRepo.update(id, permission);
  }

  delete(id: number) {
    return this.permissionRepo.delete(id);
  }
}