import { Category } from 'src/category/category.entity';
import { Entity, PrimaryGeneratedColumn, Column, ManyToOne, JoinColumn } from 'typeorm';

@Entity('products')
export class Product {
  @PrimaryGeneratedColumn()
  id: number;

  @Column() category_name: string;
  @Column() brand_name: string;
  @Column() brand_model: string;
  @Column('json') metadata: Record<string, any>;
  @Column('decimal') product_price: number;
  @Column() product_quantity: number;

  @ManyToOne(() => Category, (category) => category.products)
  @JoinColumn({ name: 'category_id' })
  category: Category;
}