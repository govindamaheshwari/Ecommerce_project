import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import * as dotenv from 'dotenv';
import { UserModule } from './modules/user/user.module';
import { AppService } from './app.service';
import { AppController } from './app.controller';
dotenv.config(); // ✅ Load env variables from .env file

// ✅ Print env values to verify they're loaded
console.log('DB_USERNAME:', process.env.DB_USERNAME);
console.log('DB_PASSWORD:', process.env.DB_PASSWORD);
console.log('DB_NAME:', process.env.DB_NAME);
console.log(__dirname)

@Module({
  imports: [
    TypeOrmModule.forRoot({
      type: 'mysql',
      host: process.env.DB_HOST || 'localhost',
      port: parseInt(process.env.DB_PORT || '3306'),
      username: process.env.DB_USERNAME || 'nest_user',
      password: process.env.DB_PASSWORD || 'nest_pass_123',
      database: process.env.DB_NAME || 'ecommerce',
      entities: [__dirname + '/modules/**/*.entity{.ts,.js}'],
      synchronize:true,
    }),
    UserModule
  ],
  controllers: [AppController],     // ✅ Register Controller
  providers: [AppService],
})
export class AppModule {}
